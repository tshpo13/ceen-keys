﻿Option Strict On
Option Infer Off
Option Explicit On


Public Interface IPerson

    Property Name As String
    Property Surname As String

End Interface
