﻿Option Explicit On
Option Strict On
Option Infer Off

Public Class Non_Recycable
    Inherits Items
    Private _Dispose As String
    Private _AverageWaste As Double

    Public Property Dispose() As String
        Get
            Return _Dispose
        End Get
        Set(value As String)

            _Dispose = value
        End Set
    End Property

    Public Property AveWaste() As Double ' property return averagewaste 
        Get
            Return _AverageWaste
        End Get
        Set(value As Double)
            _AverageWaste = value
        End Set
    End Property

    Public Function CalcAverage(numWaste As Integer, numItems As Integer) As Double 'function calculates average waste disposed of non_recycable items 

        AveWaste = numWaste / numItems
        Return AveWaste
    End Function

    Public Function CalcRating() As String 'calculating a rating given an average

        Dim Rating As String = " "
        Select Case AveWaste
            Case Is < 1 / 2 * 100
                Rating = "Fewer waste disposed.Atleast only less number of non-recycable items is disposed,and the rest is useful. Excellent."
            Case Is = 1 / 2 * 100
                Rating = "Half of the items is disposed as waste.Try to reduse purchasing less reusable items.Re-use items you have than to dispose them"
            Case Is > 1 / 2 * 100
                Rating = "Too many items wasted,Intervention needed for improvement. Try to reduse purchasing less reusable items"

        End Select

        Return Rating
    End Function

    Public Function DetermineWasteLevel() As String 'Determining the level of Waste disposed
        Dim level As String = ""

        Select Case AveWaste
            Case < 40
                level = "C"
            Case >= 40
                level = " B"
            Case >= 70
                level = "A"
        End Select
        Return level
    End Function

    Public Overrides Function Display() As String 'Dispay data

        Return "Rating : " & CalcRating() & "Waste Level : " & DetermineWasteLevel() & Environment.NewLine & MyBase.Display
    End Function

End Class
